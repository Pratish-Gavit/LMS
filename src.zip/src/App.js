 import 'antd/dist/antd.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Components/Login/Login';
import Admin from './Components/Admin/Admin';
import './App.css';
import Mentor from './Components/Mentor/Mentor';
import EmployeeReg from './Components/Employee.js/EmployeeReg';




function App() {
  return (
    <div className="App">
     {/* <Login /> */}
     {/* <Admin /> */}
     <Mentor />
     {/* <EmployeeReg /> */}
    </div>
  );
}

export default App;
