import React from 'react'
import './Login.css'


function Login() {

  return (
<div id='bg'>

<div id='box1'>

  <div id='box2'>

  </div>
  <div id='box11'>
  Good things on <br/> your way!
 
  </div>
</div>
</div>

  )
}

export default Login